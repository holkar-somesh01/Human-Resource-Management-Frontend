import React from 'react'
import Leaves from '../../component/admin/Leaves'

const HrDashboard = () => {
  return (
    <>
      <Leaves />
    </>
  )
}

export default HrDashboard